const express = require('express')
const dotenv = require("dotenv")
const colors = require('colors');
const morgan = require( 'morgan');
const connectDB = require('./config/db')
var cors = require('cors');
var helmet = require('helmet')



// flixtechs
import { remindTicket } from './tasks/remindTicket';

import { engine } from 'express-edge'
import { ValidationError } from 'express-validation'
import override from 'method-override'
import web from './routes/web'
import auth from './routes/auth'
import passport from 'passport'
import session from 'express-session'
import flash from 'connect-flash'
import bodyParser from 'body-parser'
import setupPassport from '@/config/passport'





dotenv.config({path: './config/config.env'});

const routes = require('./routes/routes')

connectDB();
setupPassport()

const app = express();




app.use(express.static('public'))
app.use(override('_method'))

app.use(session({
    secret: process.env.APP_KEY,
    resave: false,
    saveUninitialized: false
}))

app.use(passport.initialize());
app.use(passport.session());

app.use(flash())


app.use(cors());
app.use(helmet());
app.use(express.json());
app.use(bodyParser.urlencoded({extended: true}))

app.use(engine)
app.set('views', './views');

app.use('/api', routes);
app.use(web)
app.use(auth)


app.use(function(err, req, res, next) {
    if (err instanceof ValidationError) {
        req.flash('error', err)
        return res.redirect(req.originalUrl)
    }
  
    return next()
})

app.listen(process.env.PORT || 5000, () => {
    console.log(`Serverr Runninng in ${process.env.NODE_ENV} mode on port ${process.env.PORT}`.yellow.bold)
    setInterval(remindTicket, 3000);
})
