import mongoose from 'mongoose'

const Schema = mongoose.Schema;

const Ticket = new Schema({
    entered_at: Date,
    departed_at: Date,
    begin_at: Date,
    end_at: Date,
    slot :{
        type:mongoose.Schema.Types.ObjectId,
        ref:'Slot'
    },
    number_plate: String,
    user :{
        type:mongoose.Schema.Types.ObjectId,
        ref:'User'
    }
}, { timestamps: true });


export default mongoose.model('Ticket', Ticket);