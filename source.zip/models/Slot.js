import mongoose from 'mongoose'

const Schema = mongoose.Schema;

const Slot = new Schema({
    number: Number,
    occupied: Boolean,
    ticktes: [
        {type: mongoose.Schema.Types.ObjectId, ref:'Ticket'}
    ]
}, { timestamps: true });


export default mongoose.model('Slot', Slot);