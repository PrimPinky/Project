// const mongoose = require('mongoose');


// const AuthentificationScheme = new mongoose.Schema({ 
//     FullName: {
//         type: String,
//         required: [true, 'please select a name to give the account'],
       
//         trim: true

//     },
//     RegNumber:{
//         type: String,
//         required: [true, 'please enter your student reg number'],
//         unique: [true, 'that reg number is already in use'],
//         trim: true
//     },
//     CarType: {
//         type: String,
//         required: [true, 'enter your car type'],
//         trim: true
//     },
//     NumberPlate:{
//         type: String,
//         required: [true, 'please enter the number plate for the car'],
//         trim: true,
//     },
//     password: {
//         type: String,
//         trim: true, 
//         required: [true, 'please select a password to use'],
//         minlength: [7, 'your password must have at least seven characters']
//     },
//     password2: {
//         type: String,
//         trim: true, 
//         required: [false, 'please verify your password'],
//     },
    
// })

// module.exports = mongoose.model('Auth', AuthentificationScheme);