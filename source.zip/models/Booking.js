const mongoose = require('mongoose');


const BookingScheme = new mongoose.Schema({ 
    
    RegNumber:{
        type: String,
        required: [true, 'please enter your student reg number'],
        unique: [true, 'that reg number is already in use'],
        trim: true
    },
   
    DateForBook: {
        type: String,
        required: [true, 'please enter the date that is to be reserved']
    },
    TimeofBook: {
        type: String,
        required: [true, 'please enter the time you want to reserve.'],
        trim: true
    },
    Slot: {
        type: String,
        required: [true, "please select the parking slot from the list of availbale options"],
        unique: [true, "the slot has already been assigned please find another"],
        trim: true,
    }


})

module.exports = mongoose.model('Book', BookingScheme);