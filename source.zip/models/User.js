import mongoose from 'mongoose'
import passportLocalMongoose from 'passport-local-mongoose'

const Schema = mongoose.Schema;

const User = new Schema({
    name: String,
    email: String,
    number: String,
    password: String,
    role: {
        type: Number, default: 1
    },
    ticktes: [
        {type: mongoose.Schema.Types.ObjectId, ref:'Ticket'}
    ]
});

User.plugin(passportLocalMongoose, { usernameField: 'email' });

export default mongoose.model('User', User);