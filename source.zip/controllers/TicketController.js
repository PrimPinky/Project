import Ticket from "@/models/Ticket";
import Slot from "@/models/Slot";
import User from '@/models/User'
import moment from 'moment'

export const TicketController = {
    /**
     * List all tickets
     *
     * @param {express.request} req
     * @param {express.response} res
     * @returns express.response.redirect
     */
    async index(req, res) {
      let tickets = await Ticket.find()
      .populate('user')
      .populate('slot')
      .lean()

      const { user } = req

      if(user.role == 1) {
        tickets = tickets.filter((ticket) => {
            return ticket.user._id.toString() == req.user._id.toString()
          })
      }

      res.locals.success = req.flash('success')

        return res.render("tickets/index", { tickets, moment, user });
    },

    /**
     * Show the form to create ticket
     *
     * @param {express.request} req
     * @param {express.response} res
     * @returns express.redirect
     */
    create(req, res) {
        return res.render("tickets/create");
    },

    /**
     * Store and persist ticket to storage
     *
     * @param {express.request} req
     * @param {express.response} res
     * @returns express.response
     */
    async store(req, res) {
        const { begin_at, end_at, number_plate } = req.body;
        const { _id } = req.user

        const slots = await Slot.find({ occupied: false })

        if (slots.length < 1) {
            return res.redirect('/bookings/create')
        }

        const slot = slots.pop()

        slot.occupied = true
        await slot.save()

        await slot.update({ occupied: true })

        await Ticket.create({ begin_at, end_at, number_plate, slot:slot._id, user:_id });

        req.flash("success", `You have successfuly booked slot #${slot.number}`);

        return res.redirect("/bookings");
    },

    /**
     * Update the ticket
     *
     * @param {express.request} req
     * @param {express.response} res
     */
    async update(req, res) {
        const ticket = await Ticket.findById(req.params.ticket)
            .populate('slot')

        const { depart, enter } = req.body


        if (enter == 1) {
            await ticket.updateOne({ entered_at: Date.now() })

            req.flash('success', 'Successfuly entered to parking sport')
            return res.redirect('/bookings')
        }

        await ticket.updateOne({ departed_at: Date.now() })
        
        await ticket.slot
            .updateOne({ occupied: false })

        req.flash('success', 'Successfuly left the parking spot')

        return res.redirect('/bookings')
    },

      /**
     * Update the ticket
     *
     * @param {express.request} req
     * @param {express.response} res
     */
       async reschedule(req, res) {
        const ticket = await Ticket.findById(req.params.ticket)
            .populate('slot')

        const { begin_at, end_at } = req.body

        await ticket.updateOne({ end_at, begin_at, departed_at: null })
 
        req.flash('success', 'Parking ticket was successfuly rescheduled!')

        return res.redirect('/bookings')
    },

    /**
     * Show the individual ticket page
     *
     * @param {express.request} req
     * @param {express.response} res
     */
    show(req, res) {

    },

    /**
     * Delete the ticket from storage
     *
     * @param {express.request} req
     * @param {express.response} res
     */
    delete(req, res) { },
};
