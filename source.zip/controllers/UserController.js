import User from "@/models/User"
import moment from 'moment'

export const UserController = {
    /**
     *
     * @param {express.request} req
     * @param {express.response} res
     *
     * @returns {express.response}
     */
    async index(req, res) {
        const users = await User.find().lean();

        return res.render("users.index", { users, moment });
    },

    /**
     * Show form to create user
     *
     * @param {express.request} req
     * @param {express.response} res
     *
     * @returns express.response
     */
    async create(req, res) {
        return res.render("users.create");
    },

    /**
     * Update the specified resource in storage.
     *
     * @param {express.request} req
     * @param {express.response} res
     *
     * @returns express.response
     */
    async update(req, res) {
        const { name, email, password, password_confirmation, role } = req.body;

        const user = await User.findById(req.params.user);

        await user.updateOne({ name, email, role });

        if(password.length > 1) {
            await user.setPassword(password)
            await user.save()
        }

        return res.redirect("/users");
    },

    async updateProfile(req, res) {
        const { name, email, old_password, password, password_confirmation } = req.body;

        const user = req.user

        await user.updateOne({ name, email });

        if(old_password.length > 1 && password.length > 1) {
            await user.changePassword(old_password, password)
            await user.save()
        }

        return res.redirect("/users/profile");
    },

    /**
     * Show the form for editing the specified resource.
     *
     * @param {express.request} req
     * @param {express.response} res
     * @returns express.response
     */
    async edit(req, res) {
        const user = await User.findById(req.params.user);

        return res.render("users.edit", { user });
    },

    /**
     * Persist resource in storage
     *
     * @param {express.request} req
     * @param {express.response} res
     * @returns express.response
     */
    async store(req, res) {
        const { name, email, password, password_confirmation } = req.body;

        const user = await User.register({ name, email }, password);

        return res.redirect(`/users/${user._id}/edit`);
    },

    async show(req, res) {
        return res.render('users.show', { user: req.user})
    },

    /**
     * Remove specified resource from storage
     *
     * @param {express.request} req
     * @param {express.response} res
     * @returns express.response
     */
    async delete(req, res) {
        console.log('router ping')
        await User.deleteOne({_id: req.params.user });

        return res.redirect("/users");
    },
};
