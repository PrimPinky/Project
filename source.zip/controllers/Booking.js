const Booking = require('../models/Booking')

//@desc get all transaction from the api
//connected to route Get /api/v1/transactions

exports.getBooking = async (req, res, next)=>{ 
    try{
        const RegNumber = req.params.id
        Booking.find({RegNumber: RegNumber}, (err, booking)=>{
            if (!booking){
                return res.status(500).json({
                    success: false,
                    error: 'no booking under this reg number'
                }) 
            }else{
                return res.status(200).json({ 
                    success: true,
                    count: booking.length,
                    data: booking
                })
            }
        });  
    }catch (err){
        return res.status(500).json({
            success: false,
            error: 'server error'
        }) 
    }
}

//@desc Add a   transaction from the api
//connected to route Get /api/v1/transactions/:id

exports.addBooking = async(req, res, next)=>{
    try{

        
        const { RegNumber,DateForBook,TimeofBook, Slot } = req.body;
       
           
                const addbooking = await Booking.create(req.body);

                return res.status(201).json({ 
                    success: true,
                    data: addbooking,
                    message: "booking successfully added."
                })
            
        
        
    }catch (err){
        if(err.name === 'ValidationError'){
            const messages = Object.values(err.errors).map(val => val.message);

            return res.status(400).json({
                success: false,
                error: messages,
            })
        }else{
            return res.status(500).json({
                success: false,
                error: 'server error'
            }) 
        }
    }
    
}

//@desc get all transaction from the api
//connected to route Get /api/v1/transactions

exports.deleteBooking = async (req, res, next)=>{
    try {
        const booking = await Booking.findById(req.params.id);

        if (!booking){
            return res.status(404).json({
                success: false,
                error: 'No Transaction Found'
            })
        }

        await booking.remove();
        return res.status(200).json({
            success: true,
            data: {}
        });
    }catch (err){
        return res.status(500).json({
            success: false,
            error: 'Server Error'
        })
    }
}