import passport from 'passport'

export const AuthenticatedSessionController = {
    create(req, res) {
        res.locals.error = req.flash('error')
        res.locals.success = req.flash('success')
        res.locals.layout = 'auth'
        return res.render('auth/login', {keys: Object.keys})
    },

    store(req, res) {
        const redirectTo = req.session.redirectTo || '/'

        delete req.session.redirectTo

        return res.redirect(redirectTo)
    },

    delete(req, res) {
        req.logout()
        return res.redirect('/')
    }
}