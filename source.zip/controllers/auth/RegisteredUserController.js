import User from '@/models/User'

export const RegisteredUserController = {
    create(req, res) {
        res.locals.error = req.flash('error')
        res.locals.success = req.flash('success')
        res.locals.layout = 'auth'

        return res.render('auth/register')
    },

    async store(req, res) {

        const { email, name, password } = req.body

        const user = await User.register({ email, name }, password)

        return req.logIn(user, (err) => {
            return res.redirect('/')
        })
    }
}
