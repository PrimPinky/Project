import Slot from "@/models/Slot";

export const HomeController = {
    async index(req, res) {

        const slots = await Slot.find().lean()

        const unoccupied = slots.filter(slot => !slot.occupied).length
        const occupied = slots.filter(slot => slot.occupied).length

        return res.render('home/index', { occupied, unoccupied })
    }
}