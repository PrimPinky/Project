const express = require('express');
const router = express.Router();

// const {logIn, Register, Changepswd, getUsers} = require('../controllers/Authentification');
// const {addBooking, getBooking, deleteBooking, } =  require('../controllers/Booking');

// ///////////////////////////authentification routes//////////////
// router.post('/login',  logIn);
// router.post('/register', Register);
// router.post('/changepswd/:id', Changepswd);
// router.get('/users', getUsers);


// //booking routes

// router.get('/booking/:id', getBooking);
// router.post('/booking', addBooking);
// router.delete('/delete/:id', deleteBooking);


module.exports = router;