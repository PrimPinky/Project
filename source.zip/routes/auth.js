import express from 'express'
import passport from 'passport'
import { validate } from 'express-validation'
import { AuthenticatedSessionController } from '@/controllers/auth/AuthenticatedSessionController'
import { RegisteredUserController } from '@/controllers/auth/RegisteredUserController'
import { LoginRules } from '@/rules/LoginRules'

const router = express.Router();

router.get('/logout', AuthenticatedSessionController.delete)

router.use((req, res, next) => {
    if(req.isAuthenticated()) {
        return res.redirect('/')
    }

    return next()
})


router.get('/login', AuthenticatedSessionController.create)
router.post('/login', validate(LoginRules, {}, {}), passport.authenticate('local', { failureRedirect: '/login', failureMessage: true, failureFlash: true }), AuthenticatedSessionController.store)

router.get('/register', RegisteredUserController.create)
router.post('/register', RegisteredUserController.store)

export default router