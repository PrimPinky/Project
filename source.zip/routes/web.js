import express from 'express'
import ensure from 'connect-ensure-login'
import { HomeController } from '@/controllers/HomeController'
import { TicketController } from "@/controllers/TicketController";
import { UserController } from "@/controllers/UserController";


const router = express.Router();

//auth middleware
const whitelist = ['/login', '/register']

router.use((req, res, next) => {
    if(!req.isAuthenticated() && !whitelist.includes(req.path)) {
        req.session.redirectTo = req.url
        
        return res.redirect('/login')   
    }

    res.locals.auth = { user: req.user }

    return next()
})

router.get('/', HomeController.index)

router.get('/bookings', TicketController.index)
router.post('/bookings', TicketController.store)
router.patch('/bookings/:ticket', TicketController.update)
router.patch('/bookings/:ticket/reschedule', TicketController.reschedule)
router.get('/bookings/create', TicketController.create)
router.delete('/bookings/:ticket', TicketController.delete)
router.get('/bookigs/:ticket', TicketController.show)

router.get('/users', UserController.index)
router.get('/users/create', UserController.create)
router.post('/users', UserController.store)
router.patch('/users/:user', UserController.update)
router.get('/users/:user/edit', UserController.edit)
router.delete('/users/:user', UserController.delete)
router.get('/users/profile', UserController.show)
router.post('/users/profile', UserController.updateProfile)

export default router;