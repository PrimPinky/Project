window.$ = window.jQuery = require('jquery'); 
window.dt = require('datatables.net-bs5'); 

import 'datatables.net-bs5/css/dataTables.bootstrap5.css';

import 'bootstrap'
import 'bootstrap/dist/css/bootstrap.css'


window.jQuery(function () {
    $(".data-table").each(function (_, table) {
      $(table).DataTable({
          order: [[1, 'asc'], [3, 'desc'], [4, 'desc']],
      })
    })
})
