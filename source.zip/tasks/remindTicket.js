import Ticket from '@/models/Ticket'
import moment from 'moment'

export const remindTicket = async () => {
    const tickets = await Ticket.find({ occupied: true })

    tickets.forEach(async ticket => {
        if (moment().add(30, 'minute').isSameOrAfter(moment(ticket.beginAt)) && !ticket.entered_at) {
            await ticket.populate('slot')

            await ticket.updateOne({ departed_at: Date.now() })
        
            await ticket.slot
                .updateOne({ occupied: false })
        }
    })
}